=== QuantiModo ===
Contributors: mikepsinn
Tags: social, science
Requires at least: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Shortcodes to embed QuantiModo features on any WP page
