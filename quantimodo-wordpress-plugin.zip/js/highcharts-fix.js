;(function () {
    'use strict';

    if (Highcharts != null && Highcharts.CanVGRenderer == null) {
        Highcharts.CanVGRenderer = {};
    }
})();