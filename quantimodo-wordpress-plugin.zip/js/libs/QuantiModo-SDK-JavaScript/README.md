# QuantiModo-SDK-JavaScript
Library to make it easier for JavaScript apps to store and retrieve data using the QuantiModo API.

# Try it Out
Sign up to use the QuantiModo API for free at https://www.mashape.com/quantimodo

# API Explorer
https://app.quantimo.do/api/docs/

For more information, contact api@quantimo.do.
