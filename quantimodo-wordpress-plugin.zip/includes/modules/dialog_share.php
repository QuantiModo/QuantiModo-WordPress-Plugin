<div class="dialog-background transitions" id="share-dialog-background"></div>
<div class="dialog transitions" id="share-dialog">
    <div class="loading-overlay" id="settings-loading"></div>
    <button id="button-doshare">Share</button>
    <button id="button-cancelshare">Close</button>
</div>