<?php
/**
 * Use this file to add strings meant for localisation.
 */

if (!defined('ABSPATH')) {
    exit;
}

__('foo', 'wp-skeleton-plugin');
