# Translations

## Overview
Place your language files in this directory.

### Reference
Please visit the following links to learn more about translating WordPress themes:

  * [Plugin Handbook i18n Documenation](http://make.wordpress.org/docs/plugin-developer-handbook/plugin-components/internationalization/)
  * [I18n for WordPress Developers](http://codex.wordpress.org/I18n_for_WordPress_Developers)

